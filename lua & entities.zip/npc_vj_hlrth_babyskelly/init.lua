AddCSLuaFile("shared.lua")
include('shared.lua')
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/
ENT.Model = {"models/vj_hlr/theyhunger/babykelly.mdl"} -- The game will pick a random model from the table when the SNPC is spawned | Add as many as you want
ENT.StartHealth = 20
ENT.HullType = HULL_HUMAN
ENT.VJC_Data = {
	FirstP_Bone = "bip01 head", -- If left empty, the base will attempt to calculate a position for first person
	FirstP_Offset = Vector(5, 0, 0), -- The offset for the controller when the camera is in first person
}
---------------------------------------------------------------------------------------------------------------------------------------------
ENT.VJ_NPC_Class = {"CLASS_ZOMBIE"} -- NPCs with the same class with be allied to each other
ENT.BloodColor = "" -- The blood type, this will determine what it should use (decal, particle, etc.)
ENT.HasBloodParticle = false
ENT.HasBloodDecal = false
ENT.HasBloodPool = false -- Does it have a blood pool?

ENT.MeleeAttackDamage = 5
ENT.MeleeAttackDistance = 40 -- How close does it have to be until it attacks?
ENT.MeleeAttackDamageDistance = 70 -- How far does the damage go?
ENT.TimeUntilMeleeAttackDamage = 0.4 -- This counted in seconds | This calculates the time until it hits something
ENT.MeleeAttackExtraTimers = {0.6,1} -- Extra leap attack timers | it will run the damage code after the given amount of seconds

ENT.WaitBeforeDeathTime = 99999
ENT.HasRangeAttack = true -- Should the SNPC have a range attack?
ENT.AnimTbl_RangeAttack = {ACT_RANGE_ATTACK1} -- Range Attack Animations
ENT.RangeDistance = 1020 -- This is how far away it can shoot
ENT.RangeToMeleeDistance = 100 -- How close does it have to be until it uses melee?
ENT.TimeUntilRangeAttackProjectileRelease = 1.8 -- How much time until the projectile code is ran?
ENT.NextRangeAttackTime = 3 -- How much time until it can use a range attack?
ENT.DisableDefaultRangeAttackCode = true -- When true, it won't spawn the range attack entity, allowing you to make your own

ENT.NoChaseAfterCertainRange = true -- Should the SNPC not be able to chase when it's between number x and y?
ENT.NoChaseAfterCertainRange_FarDistance = "UseRangeDistance" -- How far until it can chase again? | "UseRangeDistance" = Use the number provided by the range attack instead
ENT.NoChaseAfterCertainRange_CloseDistance = "UseRangeDistance" -- How near until it can chase again? | "UseRangeDistance" = Use the number provided by the range attack instead
ENT.NoChaseAfterCertainRange_Type = "OnlyRange" -- "Regular" = Default behavior | "OnlyRange" = Only does it if it's able to range attack
ENT.HasDeathAnimation = true -- Does it play an animation when it dies?
ENT.AnimTbl_Death = {ACT_DIEBACKWARD,ACT_DIEFORWARD,ACT_DIESIMPLE} -- Death Animations
ENT.DeathAnimationTime = false -- Time until the SNPC spawns its corpse and gets removed
ENT.DisableFootStepSoundTimer = true -- If set to true, it will disable the time system for the footstep sound code, allowing you to use other ways like model events
ENT.HasExtraMeleeAttackSounds = true -- Set to true to use the extra melee attack sounds
ENT.HasIdleDialogueSounds = false -- If set to false, it won't play the idle dialogue sounds
ENT.HasIdleDialogueAnswerSounds = false -- If set to false, it won't play the idle dialogue answer sounds
ENT.IdleDialogueCanTurn = false -- If set to false, it won't turn when a dialogue occurs
	-- ====== Flinching Code ====== --
ENT.CanFlinch = 1 -- 0 = Don't flinch | 1 = Flinch at any damage | 2 = Flinch only from certain damages
ENT.AnimTbl_Flinch = {ACT_SMALL_FLINCH} -- If it uses normal based animation, use this
ENT.HasHitGroupFlinching = true -- It will flinch when hit in certain hitgroups | It can also have certain animations to play in certain hitgroups
ENT.HitGroupFlinching_Values = {{HitGroup = {HITGROUP_LEFTARM}, Animation = {ACT_FLINCH_LEFTARM}},{HitGroup = {HITGROUP_RIGHTARM}, Animation = {ACT_FLINCH_RIGHTARM}},{HitGroup = {HITGROUP_LEFTLEG}, Animation = {ACT_FLINCH_LEFTLEG}},{HitGroup = {HITGROUP_RIGHTLEG}, Animation = {ACT_FLINCH_RIGHTLEG}}}
	-- ====== Sound File Paths ====== --
-- Leave blank if you don't want any sounds to play
ENT.SoundTbl_FootStep = {"vj_hlr/pl_step1.wav","vj_hlr/pl_step2.wav","vj_hlr/pl_step3.wav","vj_hlr/pl_step4.wav"}
ENT.SoundTbl_Idle = {"vj_hlr/th_npc/hunger/babyslave/slv_word1.wav","vj_hlr/th_npc/hunger/babyslave/slv_word2.wav","vj_hlr/th_npc/hunger/babyslave/slv_word3.wav","vj_hlr/th_npc/hunger/babyslave/slv_word4.wav","vj_hlr/th_npc/hunger/babyslave/slv_word5.wav","vj_hlr/th_npc/hunger/babyslave/slv_word6.wav","vj_hlr/th_npc/hunger/babyslave/slv_word7.wav","vj_hlr/th_npc/hunger/babyslave/slv_word8.wav"}
ENT.SoundTbl_IdleDialogue = {"vj_hlr/th_npc/hunger/babyslave/slv_word1.wav","vj_hlr/th_npc/hunger/babyslave/slv_word2.wav","vj_hlr/th_npc/hunger/babyslave/slv_word3.wav","vj_hlr/th_npc/hunger/babyslave/slv_word4.wav","vj_hlr/th_npc/hunger/babyslave/slv_word5.wav","vj_hlr/th_npc/hunger/babyslave/slv_word6.wav","vj_hlr/th_npc/hunger/babyslave/slv_word7.wav","vj_hlr/th_npc/hunger/babyslave/slv_word8.wav"}
ENT.SoundTbl_IdleDialogueAnswer = {"vj_hlr/th_npc/hunger/babyslave/slv_word1.wav","vj_hlr/th_npc/hunger/babyslave/slv_word2.wav","vj_hlr/th_npc/hunger/babyslave/slv_word3.wav","vj_hlr/th_npc/hunger/babyslave/slv_word4.wav","vj_hlr/th_npc/hunger/babyslave/slv_word5.wav","vj_hlr/th_npc/hunger/babyslave/slv_word6.wav","vj_hlr/th_npc/hunger/babyslave/slv_word7.wav","vj_hlr/th_npc/hunger/babyslave/slv_word8.wav"}
ENT.SoundTbl_Alert = {"vj_hlr/th_npc/hunger/babyslave/slv_alert1.wav","vj_hlr/th_npc/hunger/babyslave/slv_alert3.wav","vj_hlr/th_npc/hunger/babyslave/slv_alert4.wav","vj_hlr/th_npc/hunger/babyslave/slv_word8.wav"}
ENT.SoundTbl_CombatIdle = {"vj_hlr/th_npc/hunger/babyslave/slv_alert1.wav","vj_hlr/th_npc/hunger/babyslave/slv_alert3.wav","vj_hlr/th_npc/hunger/babyslave/slv_alert4.wav"}
ENT.SoundTbl_MeleeAttackExtra = {"vj_hlr/hl1_npc/zombie/claw_strike1.wav","vj_hlr/hl1_npc/zombie/claw_strike2.wav","vj_hlr/hl1_npc/zombie/claw_strike3.wav"}
ENT.SoundTbl_MeleeAttackMiss = {"vj_hlr/hl1_npc/zombie/claw_miss1.wav","vj_hlr/hl1_npc/zombie/claw_miss2.wav"}
ENT.SoundTbl_BeforeRangeAttack = {"vj_hlr/fx/zap4.wav"}
ENT.SoundTbl_RangeAttack = {"vj_hlr/hl1_npc/hassault/hw_shoot1.wav"}
ENT.SoundTbl_Pain = {"vj_hlr/th_npc/hunger/babyslave/slv_pain1.wav","vj_hlr/th_npc/hunger/babyslave/slv_pain2.wav"}
ENT.SoundTbl_Death = {"vj_hlr/th_npc/hunger/babyslave/slv_die1.wav","vj_hlr/th_npc/hunger/babyslave/slv_die2.wav"}

ENT.FootStepSoundLevel = 60

ENT.GeneralSoundPitch1 = 100
ENT.RangeAttackPitch1 = 130
ENT.RangeAttackPitch2 = 160

-- CustomBlood_Decal
ENT.Vort_RunAway = false
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnInitialize()
	self:SetCollisionBounds(Vector(20,20,65), Vector(-20,-20,0))
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnPriorToKilled()
	self:SetCollisionBounds(Vector(10, 10, 1), Vector(-10, -10, 0))
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnAcceptInput(key, activator, caller, data)
	//print(key)
	if key == "event_emit step" or key == "step" then
		self:FootStepSoundCode()
	end
	if key == "right" or key == "left" then
		self:MeleeAttackCode()
	end
	if key == "shoot" then
		self:RangeAttackCode()
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:Vort_DoElecEffect(sp,hp,a,t)
	local elec = EffectData()
	elec:SetStart(sp)
	elec:SetOrigin(hp)
	elec:SetEntity(self)
	elec:SetAttachment(a)
	elec:SetScale(t)
	util.Effect("VJ_HLR_Electric_Charge",elec)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnRangeAttack_AfterStartTimer()
	-- Tsakh --------------------------
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*20,
				endpos = self:GetPos() + self:GetRight()*math.Rand(150,500) + self:GetUp()*-200,
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 1, randt) end
		end
	end)
	
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*20,
				endpos = self:GetPos() + self:GetRight()*math.Rand(150,500) + self:GetUp()*-200 + self:GetForward()*-math.Rand(150,500),
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 1, randt) end
		end
	end)
	
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*20,
				endpos = self:GetPos() + self:GetRight()*math.Rand(150,500) + self:GetUp()*-200 + self:GetForward()*math.Rand(150,500),
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 1, randt) end
		end
	end)
	
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*20,
				endpos = self:GetPos() + self:GetRight()*math.Rand(1,150) + self:GetUp()*200 + self:GetForward()*math.Rand(-100,100),
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 1, randt) end
		end
	end)
	
	-- Ach --------------------------
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*-20,
				endpos = self:GetPos() + self:GetRight()*-math.Rand(150,500) + self:GetUp()*-200,
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 2, randt) end
		end
	end)
	
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*-20,
				endpos = self:GetPos() + self:GetRight()*-math.Rand(150,500) + self:GetUp()*-200 + self:GetForward()*-math.Rand(150,500),
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 2, randt) end
		end
	end)
	
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*-20,
				endpos = self:GetPos() + self:GetRight()*-math.Rand(150,500) + self:GetUp()*-200 + self:GetForward()*math.Rand(150,500),
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 2, randt) end
		end
	end)
	
	local randt = math.Rand(0,0.6)
	timer.Simple(randt,function()
		if IsValid(self) then
			local tr = util.TraceLine({
				start = self:GetPos() + self:GetUp()*45 + self:GetRight()*-20,
				endpos = self:GetPos() + self:GetRight()*-math.Rand(1,150) + self:GetUp()*200 + self:GetForward()*math.Rand(-100,100),
				filter = self
			})
			if tr.Hit == true then self:Vort_DoElecEffect(tr.StartPos, tr.HitPos, 2, randt) end
		end
	end)
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomRangeAttackCode()
	local startpos = self:GetPos() + self:GetUp()*45 + self:GetForward()*40
	local tr = util.TraceLine({
		start = self:GetPos() + self:GetUp()*45 + self:GetForward()*40,
		endpos = self:GetEnemy():GetPos()+self:GetEnemy():OBBCenter(),
		filter = self
	})
	local hitpos = tr.HitPos
	
	local elec = EffectData()
	elec:SetStart(startpos)
	elec:SetOrigin(hitpos)
	elec:SetEntity(self)
	elec:SetAttachment(1)
	util.Effect("VJ_HLR_Electric",elec)
	
	local elec = EffectData()
	elec:SetStart(startpos)
	elec:SetOrigin(hitpos)
	elec:SetEntity(self)
	elec:SetAttachment(2)
	util.Effect("VJ_HLR_Electric",elec)
	
	util.VJ_SphereDamage(self,self,hitpos,30,10,DMG_SHOCK,true,false,{Force=90})
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnSchedule()
	if self.Dead == false && self.vACT_StopAttacks == false && self.Vort_RunAway == true && self.PlayingAttackAnimation == false then
		self.Vort_RunAway = false
		self:VJ_TASK_COVER_FROM_ENEMY("TASK_RUN_PATH",function(x) x.RunCode_OnFail = function() self.NextDoAnyAttackT = 0 end end)
		self.NextDoAnyAttackT = CurTime() + 5
	end
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomOnTakeDamage_AfterDamage(dmginfo,hitgroup)
	if (self.NextDoAnyAttackT + 2) > CurTime() then return end
	self.Vort_RunAway = true
end
---------------------------------------------------------------------------------------------------------------------------------------------
function ENT:CustomDeathAnimationCode(dmginfo,hitgroup)
	if hitgroup == HITGROUP_HEAD then
		self.AnimTbl_Death = {ACT_DIE_HEADSHOT}
	end
end
/*-----------------------------------------------
	*** Copyright (c) 2012-2020 by DrVrej, All rights reserved. ***
	No parts of this code or any of its contents may be reproduced, copied, modified or adapted,
	without the prior written consent of the author, unless otherwise indicated for stand-alone materials.
-----------------------------------------------*/